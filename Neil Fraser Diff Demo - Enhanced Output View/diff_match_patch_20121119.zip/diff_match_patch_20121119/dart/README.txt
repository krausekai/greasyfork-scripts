Warning:

The Dart language is currently (as of December 2011) a Technology Preview.
Until Dart has its first official release, this port of Diff Match Patch may
change from version to version to take advantage of new Dart features.

Therefore if you use this Diff Match Patch library there may be API changes
between versions and you may need to make minor updates to your code.

For example, if Dart adds enums, then DIFF_INSERT/DIFF_DELETE/DIFF_EQUAL will
become an enum.

-- Neil